The solution has been created with Visual Studio Express 2010.
Make sure to compile the Release version

Build
====
* Build the project ```rabit``` , this will give you ```rabit.lib``` in ```x64\Release```

Build Your code with rabit
====
* Add include to the dependency path of your project
* Add ```rabit.lib``` to the linker dependency  
* The project basic is an example to show you how to build rabit with basic.cc
